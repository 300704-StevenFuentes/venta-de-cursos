package course.springframework;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
